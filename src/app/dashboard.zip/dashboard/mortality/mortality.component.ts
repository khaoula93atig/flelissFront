import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mortality',
  templateUrl: './mortality.component.html',
  styleUrls: ['./mortality.component.css']
})
export class MortalityComponent implements OnInit {
  public optionsPie: any;
  constructor() { }

  ngOnInit(): void {
  }

}
